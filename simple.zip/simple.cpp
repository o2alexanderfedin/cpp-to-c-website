// Simple C++ class to test transpilation
class Calculator {
private:
    int value;
    
public:
    Calculator() : value(0) {}
    
    void add(int x) {
        value += x;
    }
    
    int getValue() const {
        return value;
    }
};

int main() {
    Calculator calc;
    calc.add(5);
    calc.add(10);
    return calc.getValue();
}
